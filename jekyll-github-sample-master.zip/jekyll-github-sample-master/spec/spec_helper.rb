require 'bundler'
Bundler.require

require 'jekyll_github_sample'